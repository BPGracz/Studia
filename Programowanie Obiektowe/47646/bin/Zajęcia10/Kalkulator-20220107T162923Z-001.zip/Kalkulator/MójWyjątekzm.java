package Zaj_08_S�uchacze_Kalk;

public class M�jWyj�tekzm extends RuntimeException{
	
	static final long serialVersionUID=10;
	double iloraz;
	
	//constructor
	public M�jWyj�tekzm(float x,float y) {   
		super("Przekroczenie zakresu warto�ci zmiennopozycyjnych");
		if(y==0.0) 
			iloraz= Double.MAX_VALUE;
		else
			iloraz=(double)x/(double)y;
	}
}

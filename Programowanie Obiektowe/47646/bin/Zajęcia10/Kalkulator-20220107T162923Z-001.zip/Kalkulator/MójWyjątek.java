package Zaj_08_S�uchacze_Kalk;

public class M�jWyj�tek extends RuntimeException{ 
	
	static final long serialVersionUID = 1;
	int suma;
	int roznica;
	long sumad;// suma "d�uga"
	long roznicad;
	
	//constuctor 1/2
	public M�jWyj�tek(short x, short y) {
		super("Przekroczenie zakresu typu short");
		suma = (int)x+ (int)y;
		roznica = (int)x-(int)y;}
	
	//constuctor 2/2
	public M�jWyj�tek(int x, int y) {
		super("Przekroczenie zakresu typu int");
		sumad = (long)x+ (long)y; //suma "d�uga"
		roznicad = (long)x-(long)y;}
}

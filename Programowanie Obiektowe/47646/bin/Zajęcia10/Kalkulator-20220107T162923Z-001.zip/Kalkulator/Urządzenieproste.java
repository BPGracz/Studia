package Zaj_08_S�uchacze_Kalk;

// dzia�aj�cy prosty kalkulator: "+", "-", "*", "/",

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Urz�dzenieproste extends Klawiatura
{
	private static final long serialVersionUID = 2;
	
	
	public short pobierzCalkowita(JTextField jtf){
			short argument;
			try {
			argument = Short.parseShort(jtf.getText());
			}
			catch(NumberFormatException x) {
				argument=0;
				System.out.println(x.toString());
			}
		    return argument;}

	
	public float pobierzRzeczywista(JTextField jtf){
	
		return Float.parseFloat(jtf.getText());}
	
	
	public Urz�dzenieproste(){
	
		ActionListener al= new ActionListener()
		{  
			
			public void actionPerformed(ActionEvent ae) 
			{
				short x,y,z;
				if (ae.getSource() == przycisk1) dispose();//przycisk1 => KONIEC
				if (ae.getSource() == poletekstowe1) 
					etykieta.setText("pole tekstowe");
				
				if (ae.getSource() == przycisk2) {         // przycisk2 = "+"
					
					x=pobierzCalkowita(poletekstowe1);
					y=pobierzCalkowita(poletekstowe2);
					z=(short)(x+y);
						//sprawdzenie przekroczenia zakresu warto�ci typu "short" po wykonaniu dodawania:
						//dodanie do siebie du�ych liczb o takich samych znakach powoduje przepe�nienie,
						//a to z kolei zmienia znak wyniku na niepoprawny:
						//tu por�wnujemy znak operanda "x" (a tym samym i "y") 
						//ze znakiem wyniku "z" "Integer.signum(x)!=Integer.signum(z)"
					boolean poprawne = !(Integer.signum(x)==Integer.signum(y) 
							&&
							Integer.signum(x)!=Integer.signum(z));
					if (poprawne)
					etykieta.setText("suma= "+z);
					
					//--- wyrzu� wyj�tek klasy M�jWyj�tek ---
					else {
						try { throw new M�jWyj�tek(x,y);}
						
						catch(M�jWyj�tek wyj�tek){
							System.out.println(wyj�tek.toString());
							etykieta.setText("skorygowane = "+wyj�tek.suma);}
					}}
								
                if (ae.getSource() == przycisk3) {        // przycisk3 = "-"
                	x=pobierzCalkowita(poletekstowe1);
                    y=pobierzCalkowita(poletekstowe2);
                    z=(short)(x-y);
                    etykieta.setText("r�nica= "+z);}
                
                if (ae.getSource() == przycisk4)         // przycisk4 = "/"
                	{
                	 float a,b,c;
                	 a = pobierzRzeczywista(poletekstowe1);
                	 b = pobierzRzeczywista(poletekstowe2);
                	 c = a/b;
                	 etykieta.setText("iloraz= "+c);
                	}
                if (ae.getSource() == przycisk5)         // przycisk5 = "*"
            	{
            	 float a,b,c;
            	 a = pobierzRzeczywista(poletekstowe1);
            	 b = pobierzRzeczywista(poletekstowe2);
            	 c = a*b;
            	 etykieta.setText("iloczyn= "+c);
            	}               	
			}				
			};
								
		przycisk1.addActionListener(al);
		przycisk3.addActionListener(al);
		przycisk2.addActionListener(al);
		przycisk4.addActionListener(al);
		przycisk5.addActionListener(al);
		poletekstowe1.addActionListener(al);
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){new Urz�dzenieproste();}
		});
	}

}
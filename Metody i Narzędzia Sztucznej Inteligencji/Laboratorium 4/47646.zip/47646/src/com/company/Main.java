package com.company;

import java.util.Random;

public class Main {

    static Random losowa = new Random();

    // funkcja (x1,x2)
    static double function(double x1,double x2) {
        double f = -(Math.pow(x1,2))-(Math.pow(x2,2))+2;
        return f;
    }

    // funkcja Rastrigina
    static double Rastrigin(int A, int n) {
        double suma = 0;
        for (int i=1; i<n ; i++) {
            double x = Math.pow(i,2) - A*Math.cos(2*Math.PI*i);
            suma =+ x;
        }
        double wynik = A*n + suma;
        return wynik;
    }

    static int[] kodowanie(){
        int binary[] = new int[38];

        for (int i=0; i<38; i++){
            binary[i] = losowa.nextInt(2);
        }
        return binary;
    }

    // mutacja
    static double mutacja(double pm, int[] osobnik) {
        for (int i=0; i<38; i++) {
            double r = losowa.nextDouble(1);
            if (r<=pm) {
                if (osobnik[i] == 1)
                    osobnik[i] = 0;
                else
                    osobnik[i] = 1;
            }
        }
        return 0;
    }

    public static void main(String[] args) {
        //polecenie 1
	    int binary[] = new int[38];
        double pm = 0.1;
        double m = mutacja(pm,binary);


        //polecenie 2
        int A = 10;
        int n = 10;

        //polecenie 3



    }
}

/*fakty*/

rodzic(elzbieta, karol).
rodzic(elzbieta,anna).
rodzic(filip,karol).
rodzic(filip, anna).
rodzic(diana, william).
rodzic(diana, harry).

kobieta(elzbieta).
kobieta(anna).
kobieta(diana).
mezczyzna(filip).
mezczyzna(karol).
mezczyzna(william).
mezczyzna(harry).

/* regu�y */
/*X jest matk� Y */
matka(X,Y) :- rodzic(X,Y), kobieta(X).
/*X jest siostr� Y */
siostra(X,Y) :- kobieta(X), matka(Z,X), matka(Z,Y).






#!/bin/sh
java -jar setup.jar
